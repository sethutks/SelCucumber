package wrappers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.browserstack.local.Local;

import utils.MailReader;
import utils.Reporter;

public class SeleniumWrapper extends Reporter {

	protected static final ThreadLocal<SeleniumWrapper> driverThreadLocal = new ThreadLocal<SeleniumWrapper>();
	public RemoteWebDriver driver;
	protected Properties prop;
	public static String environmentType;
	private String browserName, browserVersion, osName, osVersion;
	public static String appURL;
	private boolean isRemote;
	private Local l;
	private Boolean isLaunchSuccess = false;
	public static MailReader reader = new MailReader();

	public SeleniumWrapper() {
		try {
			browserName = loadPropertiesData(WrapperConstants.Driver_Config_File_Path, WrapperConstants.Browser_Name);
			browserVersion = loadPropertiesData(WrapperConstants.Driver_Config_File_Path, WrapperConstants.Browser_Version);
			osName = loadPropertiesData(WrapperConstants.Driver_Config_File_Path, WrapperConstants.OS_Name);
			osVersion = loadPropertiesData(WrapperConstants.Driver_Config_File_Path, WrapperConstants.OS_Version);
			if (loadPropertiesData(WrapperConstants.Driver_Config_File_Path,WrapperConstants.Execution_Type)
					.equalsIgnoreCase(WrapperConstants.Execution_Type_Remote)) {
				isRemote = true;
			}
			loadBuildNumber();
		} catch (Exception e) {

		} 
	}
	
	public void loadBuildNumber() {
		try {
		jenkinsBuildNumber = loadPropertiesData("./build.properties", "jenkins-build");
		}
		catch(Exception e) {
			
		}
	}
	
	
	public void loadRegionName() {
		try {
		appURL = loadPropertiesData(WrapperConstants.Driver_Config_File_Path, WrapperConstants.Application_URL);
		jenkinsRegionName = loadPropertiesData("./buildregion.properties", "jenkins-regionName");
		}
		catch(Exception e) {
			
		}
	}
	
	public String loadPropertiesData(String propPath, String propName) {
		String propData = null;
		try {
		prop = new Properties();
		prop.load(new FileInputStream(propPath));
		propData = prop.getProperty(propName);
		}
		catch(Exception e) {
			
		}
		return propData;
		
	}

	public void setDriver(SeleniumWrapper wrappers) {
		driverThreadLocal.set(wrappers);
	}

	public RemoteWebDriver getDriver() {
		return driverThreadLocal.get().driver;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public synchronized RemoteWebDriver invokeApp() {
		try {
			if (isRemote) {
				JSONParser parser = new JSONParser();
				JSONObject config = (JSONObject) parser
						.parse(new FileReader(WrapperConstants.Remote_Execution_Config_File_Path));
				JSONObject envs = (JSONObject) config.get("environments");

				DesiredCapabilities capabilities = new DesiredCapabilities();

				Map<String, String> envCapabilities = (Map<String, String>) envs.get(environmentType);
				Iterator it = envCapabilities.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry pair = (Map.Entry) it.next();
					capabilities.setCapability(pair.getKey().toString(), pair.getValue().toString());
					if (pair.getKey().toString().equals(WrapperConstants.Browser_Name)) {
						browserName = pair.getValue().toString();
					} else if (pair.getKey().toString().equals(WrapperConstants.Browser_Version)) {
						browserVersion = pair.getValue().toString();
					} else if (pair.getKey().toString().equals(WrapperConstants.OS_Name)) {
						osName = pair.getValue().toString();
					} else if (pair.getKey().toString().equals(WrapperConstants.OS_Version)) {
						osVersion = pair.getValue().toString();
					}
				}

				Map<String, String> commonCapabilities = (Map<String, String>) config.get("capabilities");
				it = commonCapabilities.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry pair = (Map.Entry) it.next();
					if (capabilities.getCapability(pair.getKey().toString()) == null) {
						capabilities.setCapability(pair.getKey().toString(), pair.getValue().toString());
					}
				}
				
				String browserStackTestName = testCaseName.substring(0, testCaseName.indexOf("("))+"_"+regionName+"_"+environmentType;
				capabilities.setCapability("name",browserStackTestName);
				capabilities.setCapability("build",jenkinsBuildNumber);
				capabilities.setCapability("project","Toonix");

				String username = System.getenv("BROWSERSTACK_USERNAME");
				if (username == null) {
					username = (String) config.get("user");
				}

				String accessKey = System.getenv("BROWSERSTACK_ACCESS_KEY");
				if (accessKey == null) {
					accessKey = (String) config.get("key");
				}

				if (capabilities.getCapability("browserstack.local") != null
						&& capabilities.getCapability("browserstack.local") == "true") {
					l = new Local();
					Map<String, String> options = new HashMap<String, String>();
					options.put("key", accessKey);
					l.start(options);
				}

				driver = new RemoteWebDriver(
						new URL("http://" + username + ":" + accessKey + "@" + config.get("server") + "/wd/hub"),
						capabilities);
			} else {
				if (browserName.equalsIgnoreCase("chrome")) {
					ChromeOptions options = new ChromeOptions();
					options.addArguments("disable-infobars");
					System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
					driver = new ChromeDriver(options);
				} else {
					System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
					driver = new FirefoxDriver();
				}
			}
			SeleniumWrapper seleniumWrapper = new SeleniumWrapper();
			seleniumWrapper.driver = driver;
			setDriver(seleniumWrapper);

			getDriver().manage().window().maximize();
			getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			getDriver().get(appURL);
			isLaunchSuccess = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return getDriver();
	}

	public void reportBrowserLaunch() {
		if (isLaunchSuccess) {
			reportStep("The " + browserName + " browser with version " + browserVersion + " in " + osName + "_"
					+ osVersion + " launched successfully", "INFO", false);
		}
	}

	public WebElement locateElement(String locator, String locValue) {
		WebElement element = null;
		try {
			switch (locator) {
			case ("id"):
				element = getDriver().findElementById(locValue);
				break;
			case ("link"):
				element = getDriver().findElementByLinkText(locValue);
				break;
			case ("xpath"):
				element = getDriver().findElementByXPath(locValue);
				break;
			case ("name"):
				element = getDriver().findElementByName(locValue);
				break;
			case ("class"):
				element = getDriver().findElementByClassName(locValue);
				break;
			case ("tag"):
				element = getDriver().findElementByTagName(locValue);
				break;
			}
		} catch (NoSuchElementException e) {
			reportStep("The element with locator " + locator + " not found.", "FAIL");
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while finding " + locator + " with the value " + locValue, "FAIL");
		}
		return element;
	}

	public void type(WebElement ele, String data,String desc) {
		try {
			ele.clear();
			ele.sendKeys(data);
			reportStep("The data: " + data + " entered successfully for the textbox " + desc, "PASS");
		} catch (NoSuchElementException e) {
			reportStep("The data: " + data + " could not be entered in the "+ desc +" field", "FAIL");
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while entering " + data + " in the field ", "FAIL");
		} catch (Exception e) {
			reportStep("Unknown exception occured while entering " + data + " in the field ", "FAIL");
		}
	}

	public void click(WebElement ele,String desc) {
		try {
			ele.click();
			reportStep(desc +" clicked successfully", "PASS");
		} catch (Exception e) {
			e.printStackTrace();
			reportStep(desc +" could not be clicked successfully", "FAIL");
		}
	}

	public String getAttribute(WebElement ele, String attribute) {
		String bReturn = "";
		try {
			return ele.getAttribute(attribute);
		} catch (Exception e) {
			reportStep("The element with attribute: " + attribute + " could not be found.", "FAIL");
		}
		return bReturn;
	}

	public void isHiddeninScreen(WebElement element,String desc) {
		try {
			boolean bHidden = element.isDisplayed();
			if (!bHidden) {
				reportStep(desc + " is hidden as expected", "PASS");
			} else {
				reportStep(desc+ " is visible but expected to be hidden", "WARN");
			}
		} catch (Exception e) {
			e.printStackTrace();
			reportStep("Unknown exception occured while verifying the " + desc + "isHidden", "FAIL");
		}
	}

	public void isDisplayedInScreen(WebElement element, String desc) {
		try {
			boolean bHidden = element.isDisplayed();
			if (bHidden) {
				reportStep(desc + " is displayed as expected", "PASS");
			} else {
				reportStep(desc + " is visible but expected to be hidden", "WARN");
			}
		} catch (Exception e) {
			e.printStackTrace();
			reportStep("Unknown exception occured while verifying the "+ desc + " isDisplay", "FAIL");
		}
	}

	public void verifyText(WebElement ele, String text,String desc) {
		try {
			String sText = ele.getText();
			if (sText.equalsIgnoreCase(text)) {
				reportStep(desc+" | Actual Value: "+sText+" matches the expected Value: "+text, "PASS");
			} else {
				reportStep("The text: " + sText + " did not match with the value :" + text +" for the element " + desc, "WARN");
			}
		} catch (Exception e) {
			e.printStackTrace();
			reportStep("Unknown exception occured while verifying the text for the element " + desc, "FAIL");
		}
	}
	
	public void verifyAttributeValue(WebElement ele, String attributeValue, String expectedText,String desc) {
		try {
			String sText = ele.getAttribute(attributeValue);
			if (sText.equalsIgnoreCase(expectedText)) {
				reportStep("The text: " + sText + " matches with the value :" + expectedText +" for the element " + desc, "PASS");
			} else {
				reportStep("The text: " + sText + " did not match with the value :" + expectedText +" for the element " + desc, "WARN");
			}
		} catch (Exception e) {
			e.printStackTrace();
			reportStep("Unknown exception occured while verifying the attribute value for the element " + desc, "FAIL");
		}
	}

	public void verifyPartialText(WebElement ele, String text,String desc) {
		try {
			String sText = ele.getText();
			if (sText.contains(text)) {
				reportStep("The text: " + sText + " contains the value :" + text +" for the element " + desc, "PASS");
			} else {
				reportStep("The text: " + sText + " did not contains the value :" + text +" for the element " + desc, "WARN");
			}
		} catch (Exception e) {
			e.printStackTrace();
			reportStep("Unknown exception occured while verifying the partial text for the element " + desc, "FAIL");
		}
	}

	public boolean verifyTitle(String title) {
		boolean bReturn = false;
		try {
			if (getDriver().getTitle().equalsIgnoreCase(title)) {
				reportStep("The title of the page matches with the value :" + title, "PASS");
				bReturn = true;
			} else
				reportStep(
						"The title of the page:" + getDriver().getTitle() + " did not match with the value :" + title,
						"SUCCESS");

		} catch (Exception e) {
			reportStep("Unknown exception occured while verifying the title", "FAIL");
		}
		return bReturn;
	}
	
	public boolean verifyElementSelected(WebElement ele, String text,String desc) {
		boolean bReturn = false;
		try {
			if (ele.isSelected()) {
				reportStep("The element with the text " +text+ " is selected for the element" + desc, "PASS");
				bReturn = true;
			} else
				reportStep("The element with the text " +text+ " is not selected for the element" + desc, "PASS");
		} catch (Exception e) {
			reportStep("Unknown exception occured for the element" + desc, "FAIL");
		}
		return bReturn;
	}

	public boolean containsTitle(String title) {
		boolean bReturn = false;
		try {
			if (getDriver().getTitle().contains(title)) {
				reportStep("The title of the page contains with the value :" + title, "PASS");
				bReturn = true;
			} else
				reportStep(
						"The title of the page:" + getDriver().getTitle() + " did not contains with the value :" + title,
						"SUCCESS");

		} catch (Exception e) {
			reportStep("Unknown exception occured while verifying the title", "FAIL");
		}
		return bReturn;
	}
	
	public void quitBrowser() {
		try {
			getDriver().quit();
			if (l != null) {
				l.stop();
			}
			reportStep("The Browser is closed", "INFO", false);
		} catch (Exception e) {
			reportStep("Unexpected error occured in Browser", "FAIL", false);
		}
	}

	public void mouseOverByXpath(String xpathVal,String desc) {
		try {
			new Actions(getDriver()).moveToElement(getDriver().findElement(By.xpath(xpathVal))).build().perform();
			reportStep("The mouse over on the element : " + desc + " is performed.", "PASS");
		} catch (Exception e) {
			reportStep("The mouse over on the element : " + desc + " could not be performed.", "FAIL");
		}
	}

	public void moveToElementAndClick(WebElement moveElement, WebElement clickElement,String desc) {
		try {
			Actions builder = new Actions(getDriver());
			builder.moveToElement(moveElement).click().perform();
			reportStep("Moved to the element " + moveElement, "PASS");
			waitUntilElementVisible(clickElement, 20,desc);
			builder.click(clickElement).perform();
			reportStep("Clicked on the element " + clickElement, "PASS");
		} catch (Exception e) {
			reportStep(
					"Move to the element " + moveElement + " and click on the element " + clickElement + " is failed",
					"FAIL");
		}

	}

	public long takeSnap() {
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L;
		try {
			FileUtils.copyFile(getDriver().getScreenshotAs(OutputType.FILE),
					new File("./reports/images/" + number + ".jpg"));
		} catch (WebDriverException e) {
			reportStep("The browser has been closed.", "FAIL");
		} catch (Exception e) {
			reportStep("The snapshot could not be taken", "WARN");
		}
		return number;
	}

	public void waitUntilElementVisible(WebElement element, long timeOutInSeconds,String desc) {
		try {
			WebDriverWait wait = new WebDriverWait(getDriver(), timeOutInSeconds);
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (TimeoutException e) {
			reportStep(desc + "element is not visible", "FAIL");
		}

	}

	public void waitForPageLoad(long timoutInMiliSeconds) {
		try {
			Thread.sleep(timoutInMiliSeconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public List<WebElement> locateElements(String locator, String locValue) {
		List<WebElement> element = null;
		try {
			switch (locator) {
			case ("id"):
				element = getDriver().findElementsById(locValue);
				break;
			case ("link"):
				element = getDriver().findElementsByLinkText(locValue);
				break;
			case ("xpath"):
				element = getDriver().findElementsByXPath(locValue);
				break;
			case ("name"):
				element = getDriver().findElementsByName(locValue);
				break;
			case ("class"):
				element = getDriver().findElementsByClassName(locValue);
				break;
			case ("tag"):
				element = getDriver().findElementsByTagName(locValue);
				break;
			}
		} catch (NoSuchElementException e) {
			reportStep("The element with locator " + locator + " not found.", "FAIL");
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while finding " + locator + " with the value " + locValue, "FAIL");
		}
		return element;
	}

	public String getText(WebElement ele) {
		String sText = null;
		try {
			sText = ele.getText();
		} catch (Exception e) {
			e.printStackTrace();
			reportStep("Unknown exception occured while retriving the text ", "FAIL");
		}
		return sText;
	}

	public void waitForTitleToLoad(String titleName, long timeOutInSeconds) {
		try {
			WebDriverWait wait = new WebDriverWait(getDriver(), timeOutInSeconds);
			wait.until(ExpectedConditions.titleContains(titleName));
		} catch (TimeoutException e) {
			reportStep("Title is not visible", "FAIL");
		}
	}
	
	private By getByObjectForLocator(String locator, String locatorValue){
		By byObject = null;
		switch(locator){
		case ("id"):
			byObject = By.id(locatorValue);
			break;
		case ("link"):
			byObject = By.linkText(locatorValue);
			break;
		case ("xpath"):
			byObject = By.xpath(locatorValue);
			break;
		case ("name"):
			byObject = By.name(locatorValue);
			break;
		case ("class"):
			byObject = By.className(locatorValue);
			break;
		case ("tag"):
			byObject = By.tagName(locatorValue);
			break;
		}
		return byObject;
	}
	
	public void waitForElementToBeClickable(String locator, String locatorValue, long timeOutInSeconds,String desc) {
		try {
			WebDriverWait wait = new WebDriverWait(getDriver(), timeOutInSeconds);
			wait.until(ExpectedConditions.elementToBeClickable(getDriver().findElement(getByObjectForLocator(locator, locatorValue))));
		} catch (TimeoutException e) {
			reportStep(desc + " element is not clickable", "FAIL");
		}
	}

	public void scrollWindow(WebElement element) {
		JavascriptExecutor jse = (JavascriptExecutor) getDriver();
		Long currentValue = (Long) jse.executeScript("return document.documentElement.scrollHeight");
		Long scrolledValue = null;
		boolean continueScrolling = false;
		try {
			do {
				jse.executeScript("arguments[0].scrollIntoView(true);", element);
				Thread.sleep(5000);
				scrolledValue = (Long) jse.executeScript("return document.documentElement.scrollHeight");
				if (scrolledValue.equals(currentValue)) {
					continueScrolling = false;
				} else {
					currentValue = scrolledValue;
					continueScrolling = true;
				}
			} while (continueScrolling);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
	}

	public void verifyHyperLink(WebElement ele, String value, String desc) {
		try {
			new Actions(getDriver()).moveToElement(ele).build().perform();
			String sText = ele.getTagName();
			if (sText.contains("a")) {
				reportStep("The " + value + " value for the element "+ desc +" is the hyperlink ", "PASS");
			} else {
				reportStep("The " + value + " value for the element " + desc +" is not the hyperlink", "WARN");
			}
		} catch (Exception e) {
			reportStep("Unknown exception occured while verifying the hyperlink for the element " + desc, "FAIL");
		}
	}
	
	public void switchToWindow(int WindowPos) {
		try {
			List<String> allWindowList = new ArrayList<String>();
			allWindowList.addAll(getDriver().getWindowHandles());
			if(allWindowList.size()>1){
				if(!allWindowList.get(WindowPos).equals(getDriver().getWindowHandle())) {
					getDriver().switchTo().window(allWindowList.get(WindowPos));
				}
			}else{
				getDriver().switchTo().window(allWindowList.get(WindowPos));
			}
			reportStep("Control Switched to "+WindowPos+" window", "PASS");
		} catch (Exception e) {
			reportStep("Exception coocured while switching window", "Fail");
		}
	}
	
	public void validateCurrentURL(String expectedText,String desc) {
		try {
			String sText = getDriver().getCurrentUrl();
			if (sText.contains(expectedText)) {
				reportStep("User successfully landed in the " + desc + " page.", "PASS");
			} else {
				reportStep("User is not successfully landed in the "+ desc +" page", "WARN");
			}
		} catch (Exception e) {
			reportStep("Unknown exception occured while validate the URL for " + desc, "FAIL");
		}
	}
	
	public String getCurrentURLInBrowser(){
		String sText = null;
		try {
			sText = getDriver().getCurrentUrl();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sText;
	}
	
	public void closeBrowser() {
		try {
			getDriver().close();
		} catch (Exception e) {
			reportStep("Unknown exception occured while closing the browser", "FAIL");
		}
	}
	
	public void verifyPartialAttributeValue(WebElement ele,String attributeName,String expectedText,String desc) {
		try {
			String sText = ele.getAttribute(attributeName);
			if (sText.contains(expectedText)) {
				reportStep("Attribute values for the element " + desc + " matches with the " + expectedText, "PASS");
			} else {
				reportStep("Attribute values for the element " + desc + " does not match with the " + expectedText, "WARN");
			}
		} catch (Exception e) {
			reportStep("Unknown exception occured while verifying the attribute values for the element " + desc, "FAIL");
		}
	}
	
	public void navigateToApp(String appName){
		getDriver().navigate().to(appName);
		reportStep("Navigated to the App", "PASS");
	}
	
	public boolean isSelected(WebElement element, String desc) {
		boolean checkBoxSelected = false;
		try {
			checkBoxSelected = element.isSelected();
			reportStep(desc + "is Selected", "PASS");
		} catch (Exception e) {
			reportStep("Unknown exception occured while verifying isSelected for the element " + desc, "FAIL");
		}
		return checkBoxSelected;
	}
	
//	Pending
	public void verifyContainsText(String actual, String expected,String desc) {
		try {
			if(actual.contains(expected)) {
				reportStep("The String "+expected+" is present in the actual text", "PASS", false);
			}else {
				reportStep("The String "+expected+" is not present in the actual text", "WARN", false);
			}
		}catch(Exception e) {
			reportStep("Exception Occured: "+e.getMessage(), "FAIL", false);
		}
	}
	
	public void navigateBackwardInBrowser(){
		try {
			getDriver().navigate().back();
			reportStep("The Back button in the browser clicked successfully", "PASS", false);
		} catch (Exception e) {
			reportStep("Exception Occured: "+e.getMessage(), "FAIL", false);
		}
		
	}
	
	public void navigateForwardInBrowser(){
		try {
			getDriver().navigate().forward();
			reportStep("The Forward button in the browser clicked successfully", "PASS", false);
		} catch (Exception e) {
			reportStep("Exception Occured: "+e.getMessage(), "FAIL", false);
		}
		
	}
	
	public void clickByJS(WebElement ele,String desc){
		try {
			getDriver().executeScript("arguments[0].click();",ele);
			reportStep(desc + " is clicked successfully", "PASS");
		} catch (Exception e) {
			reportStep("Exception Occured: "+e.getMessage(), "FAIL");
		}
		
	}
	
	public void selectByText(WebElement ele, String data, String desc) {
		try {
			Select select = new Select(ele);
			select.selectByVisibleText(data);
			reportStep("The data: " + data + " for the element "+ desc + " selected successfully", "PASS");
		} catch (NoSuchElementException e) {
			reportStep("The data: " + data + " for the element "+ desc + " could not be selected in the dropdown", "FAIL");
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while selecting " + data + " in the dropdown ", "FAIL");
		} catch (Exception e) {
			reportStep("Unknown exception occured while selecting " + data + " in the dropdown ", "FAIL");
		}
	}
	
	public void verifyElementNotPresent(String locator,String value,String desc) {
		try {
			int size = locateElements(locator,value).size();
			if (size == 0) {
				reportStep("The element "+desc+" is not present in DOM ", "PASS");
			} else {
				reportStep("The element "+desc+"  is present in DOM", "WARN");
			}
		} catch (Exception e) {
			e.printStackTrace();
			reportStep("Unknown exception occured while verifying the element is not present for "+desc, "FAIL");
		}
	}
	
	public void switchToFrame(WebElement element, String desc){
		getDriver().switchTo().frame(element);
		reportStep("Frame for "+desc+ "identified and Moved.", "INFO", false);
	}
	
}