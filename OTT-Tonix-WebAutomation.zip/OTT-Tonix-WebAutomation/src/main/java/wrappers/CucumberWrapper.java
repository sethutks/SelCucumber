package wrappers;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import toonix.common.ToonixWrapper;


public class CucumberWrapper extends TestNGWrapper {
	
	@Before
	public void launchBrowser(Scenario sc) throws InterruptedException {
		testCaseName = sc.getName();
		invokeApp();
		ToonixWrapper toonixWrapper = new ToonixWrapper();
		toonixWrapper.loadTestDataForScenario(sc.getName());
		startTestCase(sc.getName(), sc.getId(), environmentType);
		startNode(regionName);
		reportBrowserLaunch();
	}
	
	@After
	public void executeAfterScenario() {
		quitBrowser();
	}
}
