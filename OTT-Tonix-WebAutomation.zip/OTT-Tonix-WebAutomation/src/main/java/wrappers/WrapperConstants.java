package wrappers;

public class WrapperConstants {
	
	public static final String Driver_Config_File_Path = "./src/main/resources/runnerConfig/DriverConfig.properties";
	
	public static final String Execution_Type = "ExecutionType";
	
	public static final String Execution_Type_Remote = "remote";
	
	public static final String Browser_Name = "browser";
	
	public static final String Application_URL = "AppURL";
	
	public static final String Browser_Version = "browser_version";
	
	public static final String OS_Name = "os";
	
	public static final String OS_Version = "os_version";
	
	public static final String Remote_Execution_Config_File_Path = "./src/main/resources/runnerconfig/BrowserStackConfig.json";
	
	public static final String Locator_Xpath = "xpath";
	
	public static final String Locator_ID = "id";
	
	public static final String Locator_Name = "name";
	
	public static final String Locator_ClassName = "class";
	
	public static final String Locator_LinkText = "link";
	
	public static final String Locator_TagName = "tag";
	
}
