package wrappers;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class TestNGWrapper extends SeleniumWrapper {
	
	protected String mTestCaseName = "";

	@BeforeSuite
	public void beforeSuite() throws Exception{
		
		loadRegionName();
		
		if(jenkinsRegionName.equalsIgnoreCase("denmark")){
			appURL = appURL + "dk/play/beta";
			regionName = "Denmark";
		}else if(jenkinsRegionName.equalsIgnoreCase("finland")){
			appURL = appURL + "fi/play/beta";
			regionName = "Finland";
		}else if(jenkinsRegionName.equalsIgnoreCase("norway")){
			appURL = appURL + "no/play/beta";
			regionName = "Norway";
		}else if(jenkinsRegionName.equalsIgnoreCase("sweden")){
			appURL = appURL + "se/play/beta";
			regionName = "Sweden";
		}
		
		startResult();
		
	}

	@Parameters({"environment"})
	@BeforeTest
	public void setEnvironment(String environment) throws Exception{
		environmentType = environment;
//		appURL = applnURL;
//		BatchExecutorUtil.startVPNConnection(regionName);
		if(!(regionList.contains(regionName))) {
		regionList.add(regionName);
		}
	}
	
	@BeforeMethod
	public void beforeMethod(){
		
	}
		
	@AfterSuite
	public void afterSuite() throws Exception{
		endResult();
	}

	@AfterTest
	public void afterTest() throws Exception{
		environmentType = null;	
//		BatchExecutorUtil.closeVPNConnection();
	}
	
	@AfterMethod
	public void afterMethod(){
		
	}	
}
