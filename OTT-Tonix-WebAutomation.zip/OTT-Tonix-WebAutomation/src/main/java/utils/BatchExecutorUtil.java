package utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BatchExecutorUtil {

	public static void startVPNConnection(String region) throws Exception {
		switch (region) {
		case "Denmark":
			executebatch("ConnectDenmark");
			break;
		case "Sweden":
			executebatch("ConnectSweden");
			break;
		case "Finland":
			executebatch("ConnectFinland");
			break;
		case "Norway":
			executebatch("ConnectNorway");
			break;
		default:
			throw new RuntimeException("Specified VPN does not supported by Toonix");
		}
	}
	
	public static void closeVPNConnection() throws Exception{
		executebatch("DisconnectVPN");
	}

	private static void executebatch(String batchFileName) throws Exception {
		Runtime runtime = Runtime.getRuntime();
		String baseProjectPath = System.getProperty("user.dir");
		String completePath = baseProjectPath + "/src/test/resources/batches/" + batchFileName + ".bat";
		Process p1 = runtime.exec(completePath);
		BufferedReader reader = new BufferedReader(new InputStreamReader(p1.getInputStream()));
		String line = null;
		while ((line = reader.readLine()) != null) {
			if (line.contains("Command completed successfully")) {
				System.out.println("Connected to / Disconnected from the region successfully");
			} else if (line.contains("The remote connection was denied")) {
				throw new RuntimeException("Connection to Vypr is failed");
			}
		}
	}
}
