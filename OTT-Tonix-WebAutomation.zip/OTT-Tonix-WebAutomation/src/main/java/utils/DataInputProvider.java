package utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

import com.esotericsoftware.yamlbeans.YamlException;
import com.esotericsoftware.yamlbeans.YamlReader;

public class DataInputProvider {

	private YamlReader yamlReader = null;
	public Map<String, String> ymlFileData = new HashMap<String, String>();
	private Map<String, String> testDataMap = new HashMap<String, String>();

	@SuppressWarnings("unchecked")
	public Map<String, String> objectRepositoryReader(String filePath) {
		try {
			yamlReader = new YamlReader(new FileReader(filePath));
			ymlFileData = (Map<String, String>) yamlReader.read();
		} catch (YamlException e) {

		} catch (FileNotFoundException e) {

		}
		return ymlFileData;

	}

	@SuppressWarnings("unchecked")
	public Map<String, String> readTestData(String filePath, String scenarioName) {
		try {
			yamlReader = new YamlReader(new FileReader(filePath));
			Map<Object, Object> entireYmlData = (Map<Object, Object>) yamlReader.read();
			testDataMap = (Map<String, String>) entireYmlData.get(scenarioName);
		} catch (YamlException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return testDataMap;

	}

}
