package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeMultipart;

public class MailReader {
	static String mailText = "";
	public static Message[] messages = null;
	public static Folder inbox;
	public static Store store;

	public MailReader() {

	}

	public static void openConnection(String emailUser, String emailPassword) {
		Properties props = new Properties();
		try {
			props.load(new FileInputStream(new File("./src/main/resources/runnerconfig/mail.properties")));
			Session session = Session.getDefaultInstance(props, null);
			store = session.getStore("imaps");
			store.connect("smtp.gmail.com", emailUser, emailPassword);
			inbox = store.getFolder("inbox");
			inbox.open(Folder.READ_WRITE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getTextMessageContent(String subject) {
		try {
			messages = inbox.getMessages();
			for (Message message : messages) {
				if (message.getSubject().equals(subject)) {
					Object content = message.getContent();
					if (content instanceof String) {
						String body = (String) content;
						if (message.isMimeType("text/html")) {
							mailText = org.jsoup.Jsoup.parse(body).text();
						}
					} else if (content instanceof MimeMultipart) {
						MimeMultipart mp = (MimeMultipart) content;
						mailText = getTextFromMimeMultipart(mp);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mailText;
	}

	public static String getRawMessageContent(String subject) {
		try {
			messages = inbox.getMessages();
			for (Message message : messages) {
				if (message.getSubject().equals(subject)) {
					Object content = message.getContent();
					if (content instanceof String) {
						String body = (String) content;
						if (message.isMimeType("text/html")) {
							mailText = body;
						}
					} else if (content instanceof MimeMultipart) {
						MimeMultipart mp = (MimeMultipart) content;
						mailText = getTextFromMimeMultipart(mp);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mailText;
	}

	private static String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws IOException, MessagingException {
		int count = mimeMultipart.getCount();
		if (count == 0)
			throw new MessagingException("Multipart with no body parts not supported.");
		boolean multipartAlt = new ContentType(mimeMultipart.getContentType()).match("multipart/alternative");
		if (multipartAlt) {
			return getTextFromBodyPart(mimeMultipart.getBodyPart(count - 1));
		}
		String result = "";
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			result += getTextFromBodyPart(bodyPart);
		}
		return result;
	}

	private static String getTextFromBodyPart(BodyPart bodyPart) throws IOException, MessagingException {
		String result = "";
		if (bodyPart.isMimeType("text/plain")) {
			result = (String) bodyPart.getContent();
		} else if (bodyPart.isMimeType("text/html")) {
			String html = (String) bodyPart.getContent();
			result = org.jsoup.Jsoup.parse(html).text();
		} else if (bodyPart.getContent() instanceof MimeMultipart) {
			result = getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent());
		}
		return result;
	}

	public static String getSenderAddress(String subject) {
		String senderAddress = "";
		try {
			messages = inbox.getMessages();
			for (Message message : messages) {
				if (message.getSubject().equals(subject)) {
					Address[] fromaddresses = message.getFrom();
					for (Address address : fromaddresses) {
						senderAddress = senderAddress.concat(address.toString());
					}
				}
			}
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return senderAddress;
	}

	public void deleteAllMessages() {
		try {
			messages = inbox.getMessages();
			if (messages.length > 0) {
				for (Message message : messages) {
					message.setFlag(Flags.Flag.DELETED, true);
				}
			}
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public void closeConnection() {
		try {
			inbox.close(true);
			store.close();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
}
