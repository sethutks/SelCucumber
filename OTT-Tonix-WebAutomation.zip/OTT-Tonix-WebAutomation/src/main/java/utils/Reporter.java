package utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public abstract class Reporter {
	
	public static ExtentHtmlReporter html;
	public static ExtentReports extent;
	public static ExtentTest test, suiteTest;
	private static Map<RemoteWebDriver,ExtentTest> testDriver;
	private static Map<RemoteWebDriver,ExtentTest> nodeDriver;
	public static String testCaseName, regionName, jenkinsBuildNumber,jenkinsRegionName;
	public static List<String> regionList;

	public abstract RemoteWebDriver getDriver();

	public void startResult() {
		testDriver = new HashMap<RemoteWebDriver, ExtentTest>();
		nodeDriver = new HashMap<RemoteWebDriver, ExtentTest>();
		regionList = new ArrayList<String>();
		html = new ExtentHtmlReporter("./reports/result.html");
		html.loadXMLConfig("./src/main/resources/runnerconfig/extent.xml");
		html.setAppendExisting(true);
		extent = new ExtentReports();		
		extent.attachReporter(html);
		extent.setSystemInfo("Application", "Toonix");
		extent.setSystemInfo("Environment", "Production");
	}

	public synchronized ExtentTest startTestCase(String testCaseName, String testDescription, String platform) {
		suiteTest = extent.createTest(testCaseName, testDescription);
		suiteTest.assignCategory(platform);
		suiteTest.assignAuthor(regionName+"_"+platform);
		testDriver.put(getDriver(), suiteTest);
		return test;
	}
	
	public synchronized ExtentTest startNode(String region) {
		ExtentTest createNode = testDriver.get(getDriver()).createNode(region);
		nodeDriver.put(getDriver(), createNode);
		return nodeDriver.get(getDriver());
		
	}

	public abstract long takeSnap();


	public void reportStep(String desc, String status, boolean bSnap)  {
		MediaEntityModelProvider img = null;
		if(bSnap && !status.equalsIgnoreCase("INFO")){
			long snapNumber = 100000L;
			snapNumber = takeSnap();
			try {
				img = MediaEntityBuilder.createScreenCaptureFromPath
						("./../reports/images/"+snapNumber+".jpg").build();
			} catch (IOException e) {
				
			}
		}
		if(status.equalsIgnoreCase("PASS")) {
			nodeDriver.get(getDriver()).pass(desc, img);		
		}else if (status.equalsIgnoreCase("FAIL")) {
			nodeDriver.get(getDriver()).fail(desc, img);
			throw new RuntimeException();
		}else if (status.equalsIgnoreCase("WARN")) {
			nodeDriver.get(getDriver()).pass(desc, img);
		}else if (status.equalsIgnoreCase("INFO")) {
			nodeDriver.get(getDriver()).info(desc);
		}						
	}


	public void reportStep(String desc, String status) {
		reportStep(desc, status, true);
	}
	
	public void setRegionNamesInReport(){
		String regions = "";
		for (String eachRegion : regionList) {
			regions = eachRegion+"/"+regions;
		}
		extent.setSystemInfo("Region", regions.substring(0, regions.length()-1));
		if(jenkinsBuildNumber==null){
			jenkinsBuildNumber = "Local Execution";
		}
		extent.setSystemInfo("Build Number", jenkinsBuildNumber);
	}

	public void endResult() {
		setRegionNamesInReport();
		extent.flush();
	}	

}