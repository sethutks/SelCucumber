package toonix.pages;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import toonix.common.ToonixWrapper;
import wrappers.WrapperConstants;

public class AccountDetailsPage extends ToonixWrapper {

	public AccountDetailsPage() {

	}

	@Then("Verify Account details page launched successfully")
	public void verifyAccountDetailsPage() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath,
						toonixObjectRepository.get("Toonix_AccountDetails_Header")),
				20, toonixObjectRepository.get("Toonix_AccountDetails"));
		verifyText(
				locateElement(WrapperConstants.Locator_Xpath,
						toonixObjectRepository.get("Toonix_AccountDetails_Header")),
				toonixObjectRepository.get("Toonix_AccountDetails"), "Account details page launched successfully");
	}

	@And("User navigates to Add Profile Page")
	public void clickAddProfileIcon() {

		int profileCount = locateElements(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_Profile_VerifyProfiles")).size();

		if (profileCount >= 4) {

			waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")), 20, "Profile button");
			click(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")), "Click on Profile name");

			waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_DeleteProfile")), 20, "Delete button");
			click(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_DeleteProfile")), "Click on Delete button");

			waitUntilElementVisible(
					locateElement(WrapperConstants.Locator_Xpath,
							toonixObjectRepository.get("Toonix_Profile_DeleteProfileConfirmation")),
					20, "Delete button");
			click(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_DeleteProfileConfirmation")), "Click on Delete button");
			waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")), 20, "Profile button");

		}

		waitUntilElementVisible(locateElement(WrapperConstants.Locator_ClassName,
				toonixObjectRepository.get("Toonix_Add_Profile_Button")), 20, "Add Profile button");
		click(locateElement(WrapperConstants.Locator_ClassName,
				toonixObjectRepository.get("Toonix_Add_Profile_Button")), "Add Profile button");

	}

	@And("User click on guest link")
	public void guestProfile(){
		
		waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_Guest")), 20, "Guest Profile button");
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_Guest")), "Click Guest Profile button");
	}
	
	
	
	@Then("Verify First name field is editable")
	public void editProfile() {

	}

	@And("User verify the profile is present or not")
	public void verifyProfile() {

		int profileCount = locateElements(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_Profile_VerifyProfiles")).size();

		if (profileCount == 0) {

			// waitUntilElementVisible(locateElement(WrapperConstants.Locator_ClassName,
			// toonixObjectRepository.get("Toonix_Add_Profile_Button")), 20,
			// "Add Profile button");
			// click(locateElement(WrapperConstants.Locator_ClassName,
			// toonixObjectRepository.get("Toonix_Add_Profile_Button")), "Add
			// Profile button");
			// waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
			// toonixObjectRepository.get("Toonix_CreateProfile_Name")), 20,
			// "Profile Name");
			// type(locateElement(WrapperConstants.Locator_Xpath,
			// toonixObjectRepository.get("Toonix_CreateProfile_Name")),
			// toonixTestData.get("ProfileName"), "Profile Name");
			//
			// waitUntilElementVisible(
			// locateElement(WrapperConstants.Locator_ClassName,
			// toonixObjectRepository.get("Toonix_CreateProfile_AcceptTerms")),
			// 20, "Terms and Conditions CheckBox");
			// click(locateElement(WrapperConstants.Locator_ClassName,
			// toonixObjectRepository.get("Toonix_CreateProfile_AcceptTerms")),
			// "Terms and Conditions CheckBox");
			// waitUntilElementVisible(
			// locateElement(WrapperConstants.Locator_Xpath,
			// toonixObjectRepository.get("Toonix_CreateProfile_SubmitButton")),
			// 20, "Create Profile Submit Button");
			// click(locateElement(WrapperConstants.Locator_Xpath,
			// toonixObjectRepository.get("Toonix_CreateProfile_SubmitButton")),
			// "Create Profile Submit Button");
			// waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
			// toonixObjectRepository.get("Toonix_CreateProfile_ConfirmProfile")),
			// 20, "Create Profile");
			// click(locateElement(WrapperConstants.Locator_Xpath,
			// toonixObjectRepository.get("Toonix_CreateProfile_ConfirmProfile")),
			// "Create Profile");
			// verifyPartialText(
			// locateElement(WrapperConstants.Locator_Xpath,
			// toonixObjectRepository.get("Toonix_CreateProfile_ValidationMsg")),
			// toonixTestData.get("SuccessMessage"), "Profile Created
			// Successfully");
		}

	}

	@And("User delete the profile")
	public void deleteProfile() {

		waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")), 20, "Profile button");

		int profileCount = locateElements(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_Profile_VerifyProfiles")).size();

		if (profileCount > 1) {

			waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")), 20, "Profile button");
			click(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")), "Click on Profile name");

			waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_DeleteProfile")), 20, "Delete button");
			click(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_DeleteProfile")), "Click on Delete button");

			waitUntilElementVisible(
					locateElement(WrapperConstants.Locator_Xpath,
							toonixObjectRepository.get("Toonix_Profile_DeleteProfileConfirmation")),
					20, "Delete button");
			click(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_DeleteProfileConfirmation")), "Click on Delete button");
			waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")), 20, "Profile button");

		}

	}

	@And("User click on the profile")
	public void clickOnProfile() {
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")), "User profile");
	}

	@And("User change the first name")
	public void changeFirstName() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_CreateProfile_Name")),
				20, "Profile Name");
		type(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_CreateProfile_Name")),
				toonixTestData.get("ChangedProfileName"), "Profile name");
	}

	@And("User save the profile")
	public void saveProfile() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_ClassName,
						toonixObjectRepository.get("Toonix_CreateProfile_AcceptTerms")),
				20, "Terms and Conditions CheckBox");
		click(locateElement(WrapperConstants.Locator_ClassName,
				toonixObjectRepository.get("Toonix_CreateProfile_AcceptTerms")), "Terms and Conditions CheckBox");
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Profile_Save")), 20,
				"Click Profile Save Button");
		click(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Profile_Save")),
				"Click Profile Save Button");
	}

	@And("User verify the first name is changed")
	public void verifyFirstNameChanges() {
		verifyText(
				locateElement(WrapperConstants.Locator_Xpath,
						toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")),
				toonixTestData.get("ChangedProfileName"), "Profile name");
	}

	@Then("User verify date of birth field is ediable")
	public void verifyDataOfBirthIsEditable() {

	}

	@And("User change the date of birth")
	public void changeDOB() {
		String val1 = "[contains(.,'";
		String val2 = "')]";
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_DaySelectList")), "Day field");
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_Dayoptions") + val1 + toonixTestData.get("Day")
						+ val2),
				"Selected Day field value is");
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_MonthSelectList")), "Month field");
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_Monthoptions") + val1 + toonixTestData.get("Month")
						+ val2),
				"Selected Month field value is");
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_YearSelectList")), "Year field");
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_Yearoptions") + val1 + toonixTestData.get("Year")
						+ val2),
				"Selected Year field value is");

	}

	@Then("Verify Date of birth field is changed")
	public void verifyDOB() {
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_Profile_ClickOnProfile")), "User profile");
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Profile_VerifyDay")),
				20, "");
		verifyText(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Profile_VerifyDay")),
				toonixTestData.get("Day"), "Day field value verified");
		verifyText(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Profile_VerifyMonth")),
				toonixTestData.get("Month"), "Month field value verified");
		verifyText(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Profile_VerifyYear")),
				toonixTestData.get("Year"), "Year field value verified");
	}

	@And("User verify the first name mandatory field")
	public void verifyFirstNameMandatory() {
		waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_Profile_FirstNameErrorMessage")), 20, "");
		verifyText(
				locateElement(WrapperConstants.Locator_Xpath,
						toonixObjectRepository.get("Toonix_Profile_FirstNameErrorMessage")),
				toonixTestData.get("ErrorMessage"), "");
	}

	@When("User clicks on the Logout button")
	public void clickLogout() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_SignOut_button")), 20,
				"Sign Out button");
		waitForElementToBeClickable(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_SignOut_button"),
				20, "Sign Out button");
		clickByJS(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_SignOut_button")),
				"Sign Out button");
	}

	@Then("User should be logged out of Toonix application")
	public void validateLogOut() throws InterruptedException {
		Thread.sleep(3000);
		validateCurrentURL("login", "Login");
	}

	@And("Verify Marketing Preference Checkbox is Disabled")
	public void validateMarketingPrefChkBox() {
		waitForPageLoad(5000);
		scrollWindow(locateElement("xpath", "(//div[@class='c-settings-option__texts'])[1]/div[1]"));
		clickByJS(locateElement("xpath", "(//input[@type='checkbox'])[1]"), "Marketing Preference Checkbox");
		waitForPageLoad(2000);
		getDriver().executeScript("arguments[0].click();", locateElement("xpath", "(//input[@type='checkbox'])[1]"));
		waitForPageLoad(2000);
	}

	@And("User scroll to the bottom of the page")
	public void scrollToBottomPage() {
		waitForPageLoad(5000);
		scrollWindow(locateElement("xpath", "//div[@class='c-footer__logo']/following::button"));
	}

	@And("User clicks on the Privacy Policies")
	public void clickPrivacyPolicy() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Privacy_Policy")), 20,
				"Privacy Policy ");
		clickByJS(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Privacy_Policy")),
				"Privacy Policy ");
	}

	@And("Verify Privacy policy window is Opened")
	public void verifyPrivacyPolicy() {
		waitForPageLoad(3000);
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_SweetAlert_Ok")), 20,
				"Privacy Policy ");
		clickByJS(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_SweetAlert_Ok")),
				"Privacy Policy window Ok button ");
	}

	@And("User clicks on the Terms and Conditions")
	public void clickTermsAndConditions() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Terms_Conditions")),
				20, "Terms and Conditions ");
		clickByJS(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Terms_Conditions")),
				"Terms and Conditions ");
	}

	@And("Verify Terms and Conditions window is Opened")
	public void verifyTermsAndConditions() {
		waitForPageLoad(3000);
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_SweetAlert_Ok")), 20,
				"Terms and Conditions ");
		clickByJS(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_SweetAlert_Ok")),
				"Terms and Conditions window Ok button ");
	}

	@And("User clicks on the Cookies Policy")
	public void clickCookies() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Cookies_Policy")), 20,
				"Cookies Policy ");
		clickByJS(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_Cookies_Policy")),
				"Cookies Policy ");
	}

	@And("Verify Cookies Policy window is Opened")
	public void verifyCookiesPolicy() {
		waitForPageLoad(3000);
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_SweetAlert_Ok")), 20,
				"Cookies Policy ");
		clickByJS(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_SweetAlert_Ok")),
				"Cookies Policy window Ok button ");
	}

	@And("User navigates to Change password Page")
	public void navigateToChangePassword() {
		waitUntilElementVisible(locateElement("xpath", "//button[@class='c-btn c-btn--desktop']"), 20,
				"Change Password button in Account details Page");
		clickByJS(locateElement("xpath", "//button[@class='c-btn c-btn--desktop']"),
				"Change Password button in Account details Page");
	}

	@And("User enters the Current Password")
	public void enterOldPassword() {
		waitUntilElementVisible(locateElement("name", "oldPassword"), 20, "Old Password in the Change Password page");
		type(locateElement("name", "oldPassword"), toonixTestData.get("password"),
				"Old Password in the Change Password page");
	}

	@And("User enters the New Password")
	public void enterNewPassword() {
		waitUntilElementVisible(locateElement("name", "newPassword"), 20, "New Password in the Change Password page");
		type(locateElement("name", "newPassword"), toonixTestData.get("New Password"),
				"New Password in the Change Password page");
	}

	@And("User Confirms the New password")
	public void enterConfirmPassword() {
		waitUntilElementVisible(locateElement("name", "confirmPassword"), 20,
				"Confirm Password in the Change Password page");
		type(locateElement("name", "confirmPassword"), toonixTestData.get("New Password"),
				"Confirm Password in the Change Password page");
	}

	@And("User clicks on the Submit button in Change Password button")
	public void clickSubmitChangePassword() {
		waitUntilElementVisible(
				locateElement("xpath", "//div[@class='c-change-password__control']/button[@type='submit']"), 20,
				"Submit buttton in Change password page");
		clickByJS(locateElement("xpath", "//div[@class='c-change-password__control']/button[@type='submit']"),
				"Submit buttton in Change password page");
	}
}