package toonix.pages;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import toonix.common.ToonixWrapper;
import wrappers.WrapperConstants;

public class AddProfilePage extends ToonixWrapper {

	public AddProfilePage() {

	}

	@And("User enters the Profile name")
	public void enterProfileName() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_CreateProfile_Name")),
				20, "Profile Name");
		type(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("Toonix_CreateProfile_Name")),
				toonixTestData.get("ProfileName"), "Profile Name");
	}

	@When("User accept the terms for creating the profile")
	public void clickTermsAndConditionsRadio() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_ClassName,
						toonixObjectRepository.get("Toonix_CreateProfile_AcceptTerms")),
				20, "Terms and Conditions CheckBox");
		click(locateElement(WrapperConstants.Locator_ClassName,
				toonixObjectRepository.get("Toonix_CreateProfile_AcceptTerms")), "Terms and Conditions CheckBox");

	}

	@Then("User clicks on the Create Profile submit button")
	public void clickSaveButton() throws InterruptedException {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath,
						toonixObjectRepository.get("Toonix_CreateProfile_SubmitButton")),
				20, "Create Profile Submit Button");
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_SubmitButton")), "Create Profile Submit Button");		
	}
	
	@And("User confirms the alerts for Profile creation")
	public void confirmAlertMsg(){
		waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_ConfirmProfile")), 20, "Create Profile");
		click(locateElement(WrapperConstants.Locator_Xpath,
				toonixObjectRepository.get("Toonix_CreateProfile_ConfirmProfile")), "Create Profile");
	}

	@Then("User Profile should be created successfully")
	public void verifyProfileAdded() {
		verifyPartialText(
				locateElement(WrapperConstants.Locator_Xpath,
						toonixObjectRepository.get("Toonix_CreateProfile_ValidationMsg")),
				toonixTestData.get("SuccessMessage"), "Profile Created Successfully");
		
		String url = appURL.split("beta")[0];
		navigateToApp(url+"account");
	}

}