package toonix.pages;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import toonix.common.ToonixWrapper;
import wrappers.WrapperConstants;

public class LoginPage extends ToonixWrapper {

	public LoginPage() {
		closeCookiesNotification();
	}

	@And("User can see login page")
	public void verifyLoginDetails() {
		waitUntilElementVisible(
				locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("toonix_header_message")), 30,
				"Login header");
	}

	@And("User enter the username")
	public void enterUserName() {
		type(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("toonix_loginPage_username")),
				toonixTestData.get("username"), "Username");
	}

	@And("User enter the password")
	public void enterPassword() {
		type(locateElement(WrapperConstants.Locator_Name, toonixObjectRepository.get("toonix_loginPage_password")),
				toonixTestData.get("password"), "Password");
	}

	@When("User clicks on login button")
	public void clickLoginButton() {
		click(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("toonix_loginPage_login")), "Login button");
		//waitUntilElementVisible(locateElement("xpath", "//button[text()='OK']"), 20, "After Login pop up");
		//click(locateElement("xpath", "//button[text()='OK']"), "Ok button in popup");
	}
	
	@When("Click on the Help Button in the Login Page")
	public void clickHelpButton(){
		waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("toonix_Help_button")), 20, "Help button");
		click(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("toonix_Help_button")), "Help button");
	}
	
	@Then("Verify whether the Help Page is displayed")
	public void verifyHelpPageLoaded(){
		switchToFrame(locateElement(WrapperConstants.Locator_ID, "webWidget"), "Help Window");
		verifyText(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("toonix_Help_Title")), toonixTestData.get("Help_Page_Title"), "Help Page Title");
	}
	
	@Then("Verify the Error Message in login page")
	public void verifyLoginFailure(){
		waitUntilElementVisible(locateElement(WrapperConstants.Locator_ClassName, "c-input__error-message"), 20, "Error Message");
		verifyText(locateElement(WrapperConstants.Locator_ClassName, "c-input__error-message"), toonixTestData.get("Failure_Message"), "Login Error Message");
	}
	
	@When("User clicks on Show password icon")
	public void clickShowPassword(){
		waitUntilElementVisible(locateElement(WrapperConstants.Locator_ClassName, "c-input__password"), 20, "Show Password Icon");
		click(locateElement(WrapperConstants.Locator_ClassName, "c-input__password"), "Show Password Icon");
		waitForPageLoad(2000);
	}
	
	@Then("Verify whether the password is displayed")
	public void verifyShowPasswordFn(){
		waitForPageLoad(2000);
		waitUntilElementVisible(locateElement(WrapperConstants.Locator_Name, "login-password"), 20, "Password Field");
		verifyAttributeValue(locateElement(WrapperConstants.Locator_Name, "login-password"), "type", "text", "Password Field");
	}

}