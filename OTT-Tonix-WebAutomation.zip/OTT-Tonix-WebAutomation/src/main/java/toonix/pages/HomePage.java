package toonix.pages;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.Given;
import toonix.common.ToonixWrapper;
import wrappers.WrapperConstants;

public class HomePage extends ToonixWrapper {

	public HomePage() {

	}
	
	@Given("User navigate to toonix application")
	public void navigateToApplication() {
		waitForPageLoad(5000);
		betaSignup();
	}

	@And("User click on the login button")
	public void clickLoginButton() {
		click(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("toonix_loginPage_login")),
				"Login button");
	}

	@Then("User can see homelanding page")
	public void verifyHomeLandingPage() {
		waitForPageLoad(5000);
		click(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("toonix_loginPage_okayButton")),
				"Welcome Back Ok button");
	}

	@And("User click on add profile button")
	public void clickAddProfile() {
		waitUntilElementVisible(locateElement(WrapperConstants.Locator_ClassName,
				toonixObjectRepository.get("toonix_homePage_addProfileLink")), 20, "Add profile link");
		scrollWindow(locateElement(WrapperConstants.Locator_ClassName,
				toonixObjectRepository.get("toonix_homePage_addProfileLink")));
		isDisplayedInScreen(locateElement(WrapperConstants.Locator_ClassName,
				toonixObjectRepository.get("toonix_homePage_addProfileLink")), "Add profile link");
		click(locateElement(WrapperConstants.Locator_ClassName,
				toonixObjectRepository.get("toonix_homePage_addProfileLink")), "Add profile button");
	}

}