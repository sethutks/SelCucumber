package toonix.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;

import utils.DataInputProvider;
import utils.MailReader;
import wrappers.SeleniumWrapper;
import wrappers.WrapperConstants;

public class ToonixWrapper extends SeleniumWrapper {

	public Map<String, String> toonixObjectRepository = null;
	private DataInputProvider dataReader = new DataInputProvider();
	private String testDataFileName = null;
	public static Map<String, String> toonixTestData = new HashMap<String, String>();

	public ToonixWrapper() {
		if (regionName.contains("Denmark")) {
			toonixObjectRepository = dataReader
					.objectRepositoryReader("./src/test/resources/toonixOR/ToonixRepository_DK.yml");
			testDataFileName = "./src/test/resources/testData/ToonixTestData_DK.yml";
		} else if (regionName.contains("Sweden")) {
			toonixObjectRepository = dataReader
					.objectRepositoryReader("./src/test/resources/toonixOR/ToonixRepository_SE.yml");
			testDataFileName = "./src/test/resources/testData/ToonixTestData_SE.yml";
		} else if (regionName.contains("Norway")) {
			toonixObjectRepository = dataReader
					.objectRepositoryReader("./src/test/resources/toonixOR/ToonixRepository_NO.yml");
			testDataFileName = "./src/test/resources/testData/ToonixTestData_NO.yml";
		} else {
			toonixObjectRepository = dataReader
					.objectRepositoryReader("./src/test/resources/toonixOR/ToonixRepository_FI.yml");
			testDataFileName = "./src/test/resources/testData/ToonixTestData_FI.yml";

		}
	}

	public void openEmailConnection() {
		MailReader.openConnection(toonixObjectRepository.get("Email_UserName"),
				toonixObjectRepository.get("Email_Password"));
	}

	public void loadTestDataForScenario(String scenarioName) {
		toonixTestData = dataReader.readTestData(testDataFileName, scenarioName);
	}

	public void betaSignup() {
			waitUntilElementVisible(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("BetaPage_Passcode_InputBox")), 30, "Beta Code Textbox");
			type(locateElement(WrapperConstants.Locator_Xpath,
					toonixObjectRepository.get("BetaPage_Passcode_InputBox")), toonixTestData.get("beta_passcode"),
					"Beta Code");
			clickByJS(locateElement(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("BetaPage_Enter_Button")),
					"Enter Button");
	}
	
	public void closeCookiesNotification(){
		List<WebElement> cookiesNotification = locateElements(WrapperConstants.Locator_Xpath, toonixObjectRepository.get("toonix_cookies_notification"));
		if(cookiesNotification.size()>=1){
			click(cookiesNotification.get(0), "Cookies Notification");
		}
	}

}