package toonix.common;

public class ToonixConstants {
	
public static final String VindiciaAppURL = "https://secure.prodtest.sj.vindicia.com/login/secure";

}