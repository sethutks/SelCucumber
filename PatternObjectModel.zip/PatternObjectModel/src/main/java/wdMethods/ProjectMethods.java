package wdMethods;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class ProjectMethods extends SeMethods{

	@BeforeSuite
	public void beforeSuite(){
		startResult();
	}

	@AfterSuite
	public void afterSuite(){
		endResult();
	}
	
}
